//
//  FQcollectionLayout.h

//
//  Created by 范奇 on 16/6/14.
//  Copyright © 2016年 范奇. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FQcollectionLayout : UICollectionViewFlowLayout

@end
