//
//  main.m
//  ceshi_WKWebView
//
//  Created by 范奇 on 16/11/20.
//  Copyright © 2016年 fanqi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
