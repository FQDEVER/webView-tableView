//
//  FQ_TableViewController.h
//  ceshi_WKWebView
//
//  Created by 范奇 on 16/11/22.
//  Copyright © 2016年 fanqi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FQ_TableViewController : UITableViewController

@end
